import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import PerfilScreen from './screens/PerfilScreen';
import ProdutosScreen from './screens/ProdutosScreen';
import ContatoScreen from './screens/ContatoScreen';
import SobreScreen from './screens/SobreScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
<Stack.Screen
  name="Login"
    component={LoginScreen}
    />

        <Stack.Screen
          name="Home"
          component={HomeScreen}
        />

        <Stack.Screen
          name="Perfil"
          component={PerfilScreen}
        />

        <Stack.Screen
          name="Produtos"
          component={ProdutosScreen}
        />

        <Stack.Screen
          name="Contato"
          component={ContatoScreen}
        />

        <Stack.Screen
          name="Sobre"
          component={SobreScreen}
        />

      </Stack.Navigator>
    </NavigationContainer>
  );
}