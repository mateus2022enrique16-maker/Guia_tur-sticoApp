import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function LoginScreen({ navigation }) {
  const [usuario, setUsuario] = useState('');
    const [senha, setSenha] = useState('');

      const fazerLogin = () => {
          if (usuario === 'nassau' && senha === '2026') {
                navigation.navigate('Home');
                    } else {
                          alert('Usuário ou senha inválidos');
                              }
                                };

                                  return (
                                      <View style={styles.container}>
                                            <Text style={styles.titulo}>Bem-vindos ao Recifando!</Text>

                                                  <TextInput
                                                          style={styles.input}
                                                                  placeholder="Usuário"
                                                                          value={usuario}
                                                                                  onChangeText={setUsuario}
                                                                                        />

                                                                                              <TextInput
                                                                                                      style={styles.input}
                                                                                                              placeholder="Senha"
                                                                                                                      secureTextEntry
                                                                                                                              value={senha}
                                                                                                                                      onChangeText={setSenha}
                                                                                                                                            />

                                                                                                                                                  <Button title="Entrar" onPress={fazerLogin} />
                                                                                                                                                      </View>
                                                                                                                                                        );
                                                                                                                                                        }

                                                                                                                                                        const styles = StyleSheet.create({
                                                                                                                                                          container: {
                                                                                                                                                              flex: 1,
                                                                                                                                                                  justifyContent: 'center',
                                                                                                                                                                      padding: 20,
                                                                                                                                                                        },
                                                                                                                                                                          titulo: {
                                                                                                                                                                              fontSize: 24,
                                                                                                                                                                                  textAlign: 'center',
                                                                                                                                                                                      marginBottom: 20,
                                                                                                                                                                                        },
                                                                                                                                                                                          input: {
                                                                                                                                                                                              borderWidth: 1,
                                                                                                                                                                                                  marginBottom: 15,
                                                                                                                                                                                                      padding: 10,
                                                                                                                                                                                                          borderRadius: 5,
                                                                                                                                                                                                            },
                                                                                                                                                                                                            });