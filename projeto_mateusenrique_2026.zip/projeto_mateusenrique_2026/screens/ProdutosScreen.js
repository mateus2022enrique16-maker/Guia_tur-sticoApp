import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ProdutosScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Pontos Turísticos</Text>

      <Text style={styles.texto}> Instituto Ricardo Brennand </Text>
      <Text style={styles.texto}> Passo do Frevo</Text>
      <Text style={styles.texto}> Caixa Cultural</Text>
      <Text style={styles.texto}> Catamarã </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },

  texto: {
    fontSize: 18,
    marginBottom: 10,
  },
});