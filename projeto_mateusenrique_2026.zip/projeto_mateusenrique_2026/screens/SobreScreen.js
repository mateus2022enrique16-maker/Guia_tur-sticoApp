import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function SobreScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Sobre</Text>

      <Text style={styles.texto}>
        Este aplicativo foi desenvolvido para a disciplina de Desenvolvimento Mobile.
      </Text>

      <Text style={styles.texto}>
        O projeto utiliza React Native, Expo e navegacao entre telas.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },

  texto: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 10,
  },
});