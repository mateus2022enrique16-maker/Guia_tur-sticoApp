import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>

      <Text style={styles.titulo}>
        Recifando
      </Text>

      <Text style={styles.subtitulo}>
       Os melhores lugares de Recife você só encontra aqui!
      </Text>

      <View style={styles.botao}>
        <Button
          title="Perfil"
          onPress={() => navigation.navigate('Perfil')}
        />
      </View>

      <View style={styles.botao}>
        <Button
          title="Produtos"
          onPress={() => navigation.navigate('Produtos')}
        />
      </View>

      <View style={styles.botao}>
        <Button
          title="Contato"
          onPress={() => navigation.navigate('Contato')}
        />
      </View>

      <View style={styles.botao}>
        <Button
          title="Sobre"
          onPress={() => navigation.navigate('Sobre')}
        />
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 10,
  },

  subtitulo: {
    fontSize: 16,
    marginBottom: 30,
    textAlign: 'center',
  },

  botao: {
  width: '80%',
  marginVertical: 5,
  
  },
});