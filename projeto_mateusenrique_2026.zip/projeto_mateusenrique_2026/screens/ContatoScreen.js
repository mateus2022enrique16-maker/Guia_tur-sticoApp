import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ContatoScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Contato</Text>

      <Text style={styles.texto}>
        📧 contato@turismonassau.com
      </Text>
      <Text style={styles.texto}>
        📞 (81) 99999-9999
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },

  texto: {
    fontSize: 18,
    marginBottom: 10,
    textAlign: 'center',
  },
});